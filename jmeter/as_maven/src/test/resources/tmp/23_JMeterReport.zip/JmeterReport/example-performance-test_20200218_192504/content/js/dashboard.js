/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8809523809523809, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET Google Doodles Page-16"], "isController": false}, {"data": [0.0, 500, 1500, "Google Doodles Page"], "isController": true}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Choose user type based on provided distribution"], "isController": false}, {"data": [1.0, 500, 1500, "Configure Server URL and port"], "isController": false}, {"data": [0.0, 500, 1500, "GET Google Doodles Page"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-9"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-8"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-11"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-7"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-10"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-13"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-12"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-15"], "isController": false}, {"data": [0.5, 500, 1500, "GET Google Doodles Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "GET Google Doodles Page-14"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 20, 0, 0.0, 224.70000000000005, 4, 2048, 593.6000000000004, 1976.199999999999, 2048.0, 5.219206680584551, 598.158547674191, 1.5591360581941545], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["GET Google Doodles Page-16", 1, 0, 0.0, 184.0, 184, 184, 184.0, 184.0, 184.0, 5.434782608695652, 242.85092561141306, 0.9500254755434783], "isController": false}, {"data": ["Google Doodles Page", 1, 0, 0.0, 2048.0, 2048, 2048, 2048.0, 2048.0, 2048.0, 0.48828125, 559.600830078125, 1.4586448669433594], "isController": true}, {"data": ["GET Google Doodles Page-2", 1, 0, 0.0, 227.0, 227, 227, 227.0, 227.0, 227.0, 4.405286343612335, 1.9746351872246695, 0.5721709801762115], "isController": false}, {"data": ["GET Google Doodles Page-1", 1, 0, 0.0, 54.0, 54, 54, 54.0, 54.0, 54.0, 18.51851851851852, 13.65379050925926, 2.242476851851852], "isController": false}, {"data": ["GET Google Doodles Page-0", 1, 0, 0.0, 312.0, 312, 312, 312.0, 312.0, 312.0, 3.205128205128205, 2.306815905448718, 0.37560096153846156], "isController": false}, {"data": ["Choose user type based on provided distribution", 1, 0, 0.0, 89.0, 89, 89, 89.0, 89.0, 89.0, 11.235955056179774, 0.20847963483146068, 0.0], "isController": false}, {"data": ["Configure Server URL and port", 1, 0, 0.0, 394.0, 394, 394, 394.0, 394.0, 394.0, 2.5380710659898473, 0.0, 0.0], "isController": false}, {"data": ["GET Google Doodles Page", 1, 0, 0.0, 2048.0, 2048, 2048, 2048.0, 2048.0, 2048.0, 0.48828125, 559.600830078125, 1.4586448669433594], "isController": false}, {"data": ["GET Google Doodles Page-9", 1, 0, 0.0, 14.0, 14, 14, 14.0, 14.0, 14.0, 71.42857142857143, 14393.06640625, 12.974330357142858], "isController": false}, {"data": ["GET Google Doodles Page-8", 1, 0, 0.0, 12.0, 12, 12, 12.0, 12.0, 12.0, 83.33333333333333, 13482.991536458334, 15.625], "isController": false}, {"data": ["GET Google Doodles Page-11", 1, 0, 0.0, 14.0, 14, 14, 14.0, 14.0, 14.0, 71.42857142857143, 11966.099330357143, 13.462611607142858], "isController": false}, {"data": ["GET Google Doodles Page-7", 1, 0, 0.0, 10.0, 10, 10, 10.0, 10.0, 10.0, 100.0, 11808.3984375, 18.45703125], "isController": false}, {"data": ["GET Google Doodles Page-10", 1, 0, 0.0, 9.0, 9, 9, 9.0, 9.0, 9.0, 111.1111111111111, 6572.591145833334, 20.94184027777778], "isController": false}, {"data": ["GET Google Doodles Page-6", 1, 0, 0.0, 13.0, 13, 13, 13.0, 13.0, 13.0, 76.92307692307693, 5418.569711538462, 13.97235576923077], "isController": false}, {"data": ["GET Google Doodles Page-13", 1, 0, 0.0, 4.0, 4, 4, 4.0, 4.0, 4.0, 250.0, 7364.990234375, 37.841796875], "isController": false}, {"data": ["GET Google Doodles Page-5", 1, 0, 0.0, 38.0, 38, 38, 38.0, 38.0, 38.0, 26.31578947368421, 18.29769736842105, 4.5230263157894735], "isController": false}, {"data": ["GET Google Doodles Page-12", 1, 0, 0.0, 6.0, 6, 6, 6.0, 6.0, 6.0, 166.66666666666666, 8160.64453125, 28.483072916666664], "isController": false}, {"data": ["GET Google Doodles Page-4", 1, 0, 0.0, 428.0, 428, 428, 428.0, 428.0, 428.0, 2.336448598130841, 13.270297897196262, 0.9103935455607477], "isController": false}, {"data": ["GET Google Doodles Page-15", 1, 0, 0.0, 19.0, 19, 19, 19.0, 19.0, 19.0, 52.63157894736842, 181.69202302631578, 8.069490131578947], "isController": false}, {"data": ["GET Google Doodles Page-3", 1, 0, 0.0, 612.0, 612, 612, 612.0, 612.0, 612.0, 1.6339869281045751, 297.8627323325164, 0.19946129493464052], "isController": false}, {"data": ["GET Google Doodles Page-14", 1, 0, 0.0, 7.0, 7, 7, 7.0, 7.0, 7.0, 142.85714285714286, 7203.822544642857, 24.693080357142858], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 20, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
